<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 15-1-24
 * Time: 下午8:48
 */
phpinfo();